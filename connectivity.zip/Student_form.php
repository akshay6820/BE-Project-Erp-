<?php
class Student_form extends CI_Controller
{
	public function __construct()
    {
        parent::__construct();
		$this->load->library('session');
		$this->load->helper('url');
    }
	public function index()
	{
		if(isset($_SESSION['is_logged_in']))
		{
			$this->load->view('crm/Members_area/form_component');
		}
	}
}
?>