<?php
class Signup extends CI_Controller
{
	public function __construct()
    {
        parent::__construct();
        $this->load->model('Membership_model');
		$this->load->library('session');
		$this->load->helper('url');
    }
	
	public function index()
	{
		$this->load->helper('form');
		$this->load->library('form_validation');
		$data['title']='SignUp';
		
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|min_length[8]|matches[password]');
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('branch_name', 'Branch Name', 'required|strtolower|in_list[admin,borivali,powai,andheri,vile parle,churchgate]');
		if ($this->form_validation->run() === FALSE)
		{
			$this->load->view('crm/SignUpPage');
			$this->load->view('templates/footer');
		}
		else
		{
			if($this->Membership_model->add_user() === TRUE)
			{
				$data = array(
				'username'=> $this->input->post('username'),
				'priviledges'=>$this->input->post('branch_name'),
				'is_logged_in'=> TRUE
				);
				$this->session->set_userdata($data);
				redirect('members_area');
			}
		}
	}
	/*public function does_username_exist()
	{
		
	}*/
}
?>