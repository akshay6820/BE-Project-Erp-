<?php
class Membership_model extends CI_Model
{
	public function __construct()
    {
        $this->load->database();
    }
	public function validate_user()
	{
		$this->db->where(array('username' => $this->input->post('username'), 'password' => md5($this->input->post('password'))));
		$query=$this->db->get('users');
		//print_r($query);
		//echo md5($this->input->post('password'));
		if($query->num_rows() == 1)
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
	/*public function priviledges()
	{
		$this->db->select('priviledges'); 
		$this->db->from('users');   
		$this->db->where('username', $this->input->post('username'));
		$query=$this->db->get();
		echo $query->result();
		return $query;
	}*/
	public function add_user()
	{
		$data = array(
		'name'=> $this->input->post('name'),
		'email'=> $this->input->post('email'),
		'username'=> $this->input->post('username'),
		'password'=> md5($this->input->post('password')),
		'priviledges'=>$this->input->post('branch_name')
		);
		return $this->db->insert('users', $data);
	}
}
?>