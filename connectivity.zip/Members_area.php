<?php
class Members_area extends CI_Controller
{
	public function __construct()
    {
        parent::__construct();
		$this->load->library('session');
		$this->load->helper('url');
    }
	public function index()
	{
		if(isset($_SESSION['is_logged_in'])&&($_SESSION['priviledges']==='admin'))
		{
			$this->load->view('crm/Members_area/index');
			//echo $_SESSION['priviledges'];
		}
		else if(isset($_SESSION['is_logged_in'])&&($_SESSION['priviledges']==='borivali'))
		{
			//echo $_SESSION['priviledges'];
			$this->load->view('crm/Members_area/borivali');
		}
		else if(isset($_SESSION['is_logged_in'])&&($_SESSION['priviledges']==='andheri'))
		{
			//echo $_SESSION['priviledges'];
			$this->load->view('crm/Members_area/andheri');
		}
		else if(isset($_SESSION['is_logged_in'])&&($_SESSION['priviledges']==='powai'))
		{
			//echo $_SESSION['priviledges'];
			$this->load->view('crm/Members_area/powai');
		}
		else if(isset($_SESSION['is_logged_in'])&&($_SESSION['priviledges']==='vile parle'))
		{
			//echo $_SESSION['priviledges'];
			$this->load->view('crm/Members_area/vile parle');
		}
		else if(isset($_SESSION['is_logged_in'])&&($_SESSION['priviledges']==='churchgate'))
		{
			//echo $_SESSION['priviledges'];
			$this->load->view('crm/Members_area/churchgate');
		}
		else
		{
			echo "login or signup to access this page";
			redirect('login');
		}
	}
	public function form_component()
	{
		if(isset($_SESSION['is_logged_in']))
		{
			$this->load->view('crm/Members_area/form_component');
		}
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('login');
	}
}
?>